def hello_universe():
    print("Hello, universe from library b!")


if __name__ == "__main__":
    hello_universe()
