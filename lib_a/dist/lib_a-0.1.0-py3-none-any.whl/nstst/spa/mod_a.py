def hello_universe():
    print("Hello, universe from library a!")


if __name__ == "__main__":
    hello_universe()
